import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, Pose2D
from custom_msgs.msg import Goal  # mensaje personalizado
import math

class PIDController(Node):
    def __init__(self):
        super().__init__('pid_controller')
        self.pose_sub = self.create_subscription(Pose2D, '/pose', self.pose_callback, 10)
        self.goal_sub = self.create_subscription(Goal, '/goal', self.goal_callback, 10)
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.timer = self.create_timer(0.05, self.control_loop)

        # PID gains
        self.Kp_lin = 0.8
        self.Kp_ang = 1.5

        self.goal = Pose2D()
        self.pose = Pose2D()

    def pose_callback(self, msg):
        self.pose = msg

    def goal_callback(self, msg):
        self.goal = msg.pose

    def control_loop(self):
        dx = self.goal.x - self.pose.x
        dy = self.goal.y - self.pose.y
        distance = math.hypot(dx, dy)
        angle_to_goal = math.atan2(dy, dx)
        error_theta = angle_to_goal - self.pose.theta
        error_theta = math.atan2(math.sin(error_theta), math.cos(error_theta))  # Normaliza

        cmd = Twist()
        if distance > 0.1:
            cmd.linear.x = self.Kp_lin * distance
            cmd.angular.z = self.Kp_ang * error_theta
        else:
            cmd.linear.x = 0.0
            cmd.angular.z = 0.0

        self.cmd_pub.publish(cmd)

def main(args=None):
    rclpy.init(args=args)
    node = PIDController()
    rclpy.spin(node)
    rclpy.shutdown()
