import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose2D
from puzzlebot_controlpid.msg import Goal
import yaml
import os
import math

class PathGenerator(Node):
    def __init__(self):
        super().__init__('path_generator')

        # Leer parámetro del archivo YAML
        path_file = self.declare_parameter('path_file', '').get_parameter_value().string_value
        if not os.path.exists(path_file):
            self.get_logger().error(f"No se encontró el archivo: {path_file}")
            return

        # Leer metas desde YAML
        with open(path_file, 'r') as f:
            data = yaml.safe_load(f)
        self.goals = [(pt['x'], pt['y']) for pt in data['goals']]
        self.index = 0
        self.threshold = 0.15  # Umbral de llegada

        # Pose actual del robot
        self.pose = Pose2D()

        # Publisher y Subscriber
        self.goal_pub = self.create_publisher(Goal, '/goal', 10)
        self.pose_sub = self.create_subscription(Pose2D, '/pose', self.pose_callback, 10)

        # Temporizador
        self.timer = self.create_timer(0.1, self.publish_next_goal)

    def pose_callback(self, msg):
        self.pose = msg

    def publish_next_goal(self):
        if self.index >= len(self.goals):
            return

        gx, gy = self.goals[self.index]
        dx = gx - self.pose.x
        dy = gy - self.pose.y
        distance = math.hypot(dx, dy)

        if distance < self.threshold:
            self.get_logger().info(f"Meta {self.index} alcanzada.")
            self.index += 1
            if self.index >= len(self.goals):
                self.get_logger().info("¡Todas las metas han sido completadas!")
                return

        goal_msg = Goal()
        goal_msg.x = self.goals[self.index][0]
        goal_msg.y = self.goals[self.index][1]
        self.goal_pub.publish(goal_msg)

def main(args=None):
    rclpy.init(args=args)
    node = PathGenerator()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()