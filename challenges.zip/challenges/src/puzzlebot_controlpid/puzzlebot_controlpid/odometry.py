import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
from geometry_msgs.msg import Pose2D
import math

class Odometry(Node):
    def __init__(self):
        super().__init__('odometry')
        self.subscription_left = self.create_subscription(Float32, 'VelocityEncL', self.left_callback, 10)
        self.subscription_right = self.create_subscription(Float32, 'VelocityEncR', self.right_callback, 10)
        self.pose_publisher = self.create_publisher(Pose2D, '/pose', 10)
        self.timer = self.create_timer(0.05, self.update_pose)

        # Robot parameters
        self.r = 0.05     # Radio rueda
        self.L = 0.19     # Distancia entre ruedas
        self.dt = 0.05

        self.vl = 0.0
        self.vr = 0.0
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0

    def left_callback(self, msg):
        self.vl = msg.data

    def right_callback(self, msg):
        self.vr = msg.data

    def update_pose(self):
        v = self.r * (self.vr + self.vl) / 2.0
        w = self.r * (self.vr - self.vl) / self.L

        self.x += v * math.cos(self.theta) * self.dt
        self.y += v * math.sin(self.theta) * self.dt
        self.theta += w * self.dt
        self.theta = math.atan2(math.sin(self.theta), math.cos(self.theta))  # Normaliza

        pose = Pose2D()
        pose.x = self.x
        pose.y = self.y
        pose.theta = self.theta
        self.pose_publisher.publish(pose)

def main(args=None):
    rclpy.init(args=args)
    node = Odometry()
    rclpy.spin(node)
    rclpy.shutdown()