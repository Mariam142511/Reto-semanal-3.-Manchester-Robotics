from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='puzzlebot_controlpid',
            executable='odometry',
            name='odometry_node',
            output='screen'
        ),
        Node(
            package='puzzlebot_controlpid',
            executable='path_generator',
            name='path_generator_node',
            output='screen'
        ),
        Node(
            package='puzzlebot_controlpid',
            executable='pid_controller',
            name='pid_controller_node',
            output='screen'
        ),
    ])