from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='puzzlebot_controlpid',
            executable='odometry',
            output='screen'),
        Node(
            package='puzzlebot_controlpid',
            executable='pid_controller',
            output='screen')
    ])